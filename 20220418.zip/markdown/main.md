## Sections:

## 1:  [The Packages/Repo](https://github.com/Soviet-Linux/delevopment-docs/repo)
This is the main repo for the CCCP and Soviet Linux. I decided to move the package files out of the CCCP because it was messy.
## 2: [CCCP](https://github.com/Soviet-Linux/delevopment-docs/cccp)
The CCCP is the official soviet linux package manager , it can installe .spm files. See Installers/Package Managers To install .spm use --install parametter and to install binary packages in .tar.gz format use --binary (not yet implemented)
## 3: [Installer](https://github.com/Soviet-Linux/delevopment-docs/installer)
The purpose of the installer is to install a version of Soviet-Linux on the user's PC.
